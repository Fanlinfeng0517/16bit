package com.example.campus.module_campus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModuleCampusApplicationTests {

    @Test
    void
    contextLoads() {
    }

}

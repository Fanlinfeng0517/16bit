(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
	["chunk-96a4e134"], {
		"7e65": function(e, t, s) {},
		9406: function(e, t, s) {
			"use strict";
			s.r(t);
			var n = function() {
					var e = this,
						t = e.$createElement;
					e._self._c;
					return e._m(0)
				},
				a = [function() {
					var e = this,
						t = e.$createElement,
						s = e._self._c || t;
					return s("div", {
						staticClass: "home"
					}, [s("h2", {
						staticClass: "title"
					}, [e._v("欢迎使用"), s("span", {
						staticClass: "emphasis"
					}, [e._v("智慧云校园")]), e._v("管理系统")])])
				}],
				c = {
					name: "Home"
				},
				i = c,
				u = (s("bbb1"), s("2877")),
				l = Object(u["a"])(i, n, a, !1, null, "2bef1aba", null);
			t["default"] = l.exports
		},
		bbb1: function(e, t, s) {
			"use strict";
			s("7e65")
		}
	}
]);

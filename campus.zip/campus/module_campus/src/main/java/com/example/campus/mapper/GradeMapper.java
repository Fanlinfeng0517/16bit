package com.example.campus.mapper;

import com.example.campus.pojo.Grade;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 范林峰
* @description 针对表【tb_grade】的数据库操作Mapper
* @createDate 2024-09-10 19:03:45
* @Entity com.example.campus.pojo.Grade
*/
public interface GradeMapper extends BaseMapper<Grade> {

}





package com.example.campus.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.campus.module_campus.utils.JwtHelper;
import com.example.campus.module_campus.utils.MD5;
import com.example.campus.module_campus.utils.Result;
import com.example.campus.module_campus.utils.ResultCodeEnum;
import com.example.campus.pojo.Admin;
import com.example.campus.pojo.Student;
import com.example.campus.pojo.Teacher;
import com.example.campus.service.AdminService;
import com.example.campus.service.StudentService;
import com.example.campus.service.TeacherService;
import com.github.xiaoymin.knife4j.core.util.StrUtil;
import io.swagger.annotations.Api;
import io.swagger.models.auth.In;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.annotation.Resource;

@Api(tags = "管理员控制层")
@RestController
@EnableSwagger2 //开启
@RequestMapping("/sms/adminController")
public class AdminController {

    @Resource AdminService adminService;
    @Resource StudentService studentService;
    @Resource TeacherService teacherService;

    @RequestMapping("/getAllAdmin/{pn}/{pageSize}")
    public Result<Object> getAllAdmin(@PathVariable("pn")Integer pn,
                                      @PathVariable("pageSize")Integer pageSize,
                                      String name){
        Page<Admin> page = adminService.page(new Page<>(pn, pageSize),
                new LambdaQueryWrapper<Admin>().like(StrUtil.isNotBlank(name), Admin::getName, name).orderByDesc(Admin::getId));

        return Result.ok(page);
    }

    @PostMapping("/updatePwd/{oldPwd/{newPwd}}")
    public Result<Object> updatePwd(@PathVariable("oldPwd") String oldPwd,
                                    @PathVariable("newPwd") String newPwd,
                                    @RequestHeader("token") String token){
        //判断token是否有效
        if (JwtHelper.isExpiration(token)){
            return Result.build(null, ResultCodeEnum.TOKEN_ERROR);
        }
        //先对用户输入的原密码进行加密
        oldPwd = MD5.encrypt(oldPwd);
        //解析 token 获取用户id 根据id 查询用户密码是否输入正确
        Long userId = JwtHelper.getUserId(token);
        Integer userType = JwtHelper.getUserType(token);
        assert userType != null;
        if (userType ==1){
            Admin admin = adminService.selectAdminById(userId);
            if (!admin.getPassword().equals(oldPwd)){
                return Result.fail().message("原密码输入有误，请重新输入！");
            }
            admin.setPassword(MD5.encrypt(newPwd));
            adminService.update(admin,new LambdaQueryWrapper<Admin>().eq(Admin::getId,userId));
        } else if (userType == 2) {
            Student student = studentService.selectStudentById(userId);
            if (!student.getPassword().equals(oldPwd)){
                return Result.fail().message("原密码输入有误，请重新输入！");
            }
            student.setPassword(MD5.encrypt(newPwd));
            studentService.update(student,new LambdaQueryWrapper<Student>().eq(Student::getId,userId));
        }else {
            Teacher teacher = teacherService.selectTeacherById(userId);
            if (!teacher.getPassword().equals(oldPwd)){
                return Result.fail().message("原密码输入有误，请重新输入！");
            }
            teacher.setPassword(MD5.encrypt(newPwd));
            teacherService.update(teacher,new LambdaQueryWrapper<Teacher>().eq(Teacher::getId,userId));
        }

        return Result.ok();
    }
}

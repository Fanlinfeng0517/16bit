package com.example.campus.service;

import com.example.campus.pojo.Teacher;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 范林峰
* @description 针对表【tb_teacher】的数据库操作Service
* @createDate 2024-09-10 19:03:51
*/
public interface TeacherService extends IService<Teacher> {

    Teacher selectTeacherByUsernameAnpwd(String username, String password);

    Teacher selectTeacherById(Long userId);

}

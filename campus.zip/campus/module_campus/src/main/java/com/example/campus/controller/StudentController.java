package com.example.campus.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.campus.module_campus.utils.Result;
import com.example.campus.pojo.Student;
import com.example.campus.service.StudentService;
import com.github.xiaoymin.knife4j.core.util.StrUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.annotation.Resource;
import java.util.List;

@Api(tags = "学生控制层")
@EnableSwagger2
@RestController
@RequestMapping("/sms/studentController")
public class StudentController  {


    @Resource
    private StudentService studentService;

    @ApiOperation("分页带条件查询学生信息")
    @GetMapping("/getStudentByOpr/{pn}/{pageSize}")
    public Result<Object> getStudentByOpr(@ApiParam("当前页码") @PathVariable("pn") Integer pn,
                                          @ApiParam("每页显示的记录数") @PathVariable("pageSize") Integer pageSize,
                                          @ApiParam("请求参数中带查询的模糊条件") String name,String clazzName){

        Page<Student> page = studentService.page(new Page<>(pn, pageSize),
                new LambdaQueryWrapper<Student>().like(StrUtil.isNotBlank(name), Student::getName, name)
                        .like(StrUtil.isNotBlank(clazzName), Student::getClazzName, clazzName)
                        .orderByDesc(Student::getId));
        return Result.ok(page);
    }

    /*
    * 单条记录和批量删除 功能
    * @parm ids 请求体中 待删除的学生id集合
    * @return 返回数据
    * */
    @ApiOperation("单条记录和批量删除 功能")
    @DeleteMapping("/delStudentById")
    public Result<Object> delStudentById(@ApiParam("请求体中 待删除的学生id集合") @RequestBody List<Integer> ids){
        if(ids.size()==1){
            //单条删除
            studentService.removeById(ids.get(0));
        }else{
            studentService.removeBatchByIds(ids);
        }

        return Result.ok();
    }

    /*
    * 根据判断请求体中是否有id 来判断添加和修改 功能
    * @parm student 封装请求体中的JSON数据到 实体类Student中、
    * @return 返回成功数据
    * */

    @PostMapping("/addOrUpdateStudent")
    public Result<Object> addOrUpdateStudent(@RequestBody Student student){

        //判断请求体中是否有id 有的话视为修改 否则为添加
        Integer id = student.getId();
        if (id != null){
            studentService.update(student, new LambdaQueryWrapper<Student>().eq(Student::getId,id));
        }else {
            studentService.save(student);
        }

        return Result.ok();
    }

}

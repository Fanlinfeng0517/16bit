package com.example.campus.service;

import com.example.campus.pojo.Clazz;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 范林峰
* @description 针对表【tb_clazz】的数据库操作Service
* @createDate 2024-09-10 19:03:41
*/
public interface ClazzService extends IService<Clazz> {

}

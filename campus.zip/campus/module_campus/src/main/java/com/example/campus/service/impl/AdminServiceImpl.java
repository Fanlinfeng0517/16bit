package com.example.campus.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.campus.pojo.Admin;
import com.example.campus.service.AdminService;
import com.example.campus.mapper.AdminMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
* @author 范林峰
* @description 针对表【tb_admin】的数据库操作Service实现
* @createDate 2024-09-10 19:02:42
*/
@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin>
    implements AdminService{

    @Resource
    private AdminMapper adminMapperl;
    @Override
    public Admin selectAdminByUsernameAnpwd(String username, String password) {
        return adminMapperl.selectOne(
                new LambdaQueryWrapper<Admin>().eq(Admin::getName,username).eq(Admin::getPassword,password));

    }

    @Override
    public Admin selectAdminById(long id) {
        return adminMapperl.selectOne(
                new LambdaQueryWrapper<Admin>().eq(Admin::getId,id)
        );
    }
}





package com.example.campus.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.generator.IFill;
import com.example.campus.module_campus.utils.Result;
import com.example.campus.pojo.Clazz;
import com.example.campus.service.ClazzService;
import com.github.xiaoymin.knife4j.core.util.StrUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.models.auth.In;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.annotation.Resource;
import java.util.List;

@Api(tags = "班级控制层")
@RestController
@EnableSwagger2 //开启
@RequestMapping("/sms/clazzController")
public class ClazzController {

    @Resource
    private ClazzService clazzService;


    /*
    * 待条件的分页查询功能
    * @parm pn 当前页码
    * @parm pageSize 每页显示的记录数
    * @parm name 查询条件
    * @return 返回查询结果封装的 page对象
    * */
    @ApiOperation("根据分页条件查询班级信息")
    @RequestMapping("/getClazzsByOpr/{pn}/{pageSize}")
    public Result<Object> getClazzsByOpr(@ApiParam("当前页码") @PathVariable("pn")Integer pn,
                                         @ApiParam("每页显示的记录数") @PathVariable("pageSize")Integer pageSize,
                                         @ApiParam("查询条件") Clazz clazz){
        String gradeName = clazz.getGradeName();
        String name = clazz.getName();
        LambdaQueryWrapper<Clazz> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.like(StrUtil.isNotBlank(gradeName),Clazz::getGradeName,gradeName).
                like(StrUtil.isNotBlank(name),Clazz::getName,name);
        Page<Clazz> page = clazzService.page(new Page<>(pn, pageSize), new LambdaQueryWrapper<Clazz>().
                like(StrUtil.isNotBlank(name), Clazz::getName, name));
        return Result.ok(page);
    }

    /*
     * 根据判断请求体中是否有id 进行的添加或修改 更能
     * @parm id 封装请求体重的JSON数据到 实体类Clazz中
     * @return 返回成功数据
     * */
    @ApiOperation("根据判断请求体中是否有id 进行的添加或修改 更能")
    @PostMapping("/saveOrUpdateClazz")
    public Result<Object> saveOrUpdateClazz(@ApiParam("封装请求体重的JSON数据到 实体类Clazz中")@RequestBody Clazz clazz){
        Integer id = clazz.getId();
        //判断请求体中是否有id 有的话则为修改 否则为添加
        if (id != null){
            clazzService.update(clazz,new LambdaQueryWrapper<Clazz>().eq(Clazz::getId,id));
        }else {
            clazzService.save(clazz);
        }

        return Result.ok();
    }

    /*
    * 单挑记录和批量删除 功能
    * @parm ids 请求体中的 待删除的班级id集合
    * @return 返回数据
    * */
    @ApiOperation("单条记录和批量删除 功能")
    @DeleteMapping("/deledtClazz")
    public Result<Object> deleteClazz(@ApiParam("请求体中的 待删除的班级id集合")@RequestBody List<Integer> ids){
        if (ids.size()==1){
            //单条记录删除
            clazzService.removeById(ids.get(0));
        }else {
            //批量删除
            clazzService.removeByIds(ids);
        }
        return Result.ok();
    }

    @ApiOperation("获取所有班级的JSON")
    @GetMapping("/getClazzs")
    public Result<Object> getClazzs(){
        List<Clazz> clazzs = clazzService.list();
        return Result.ok(clazzs);

    }

}

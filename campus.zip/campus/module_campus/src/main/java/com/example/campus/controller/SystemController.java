package com.example.campus.controller;

import com.example.campus.module_campus.utils.*;
import com.example.campus.pojo.Admin;
import com.example.campus.pojo.LoginForm;
import com.example.campus.pojo.Student;
import com.example.campus.pojo.Teacher;
import com.example.campus.service.AdminService;
import com.example.campus.service.StudentService;
import com.example.campus.service.TeacherService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.omg.IOP.ServiceContext;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

@Api(tags = "系统控制层")
@RestController
@RequestMapping("/sms/system")
public class SystemController {

    //引入数据类型
    @Resource
    private AdminService adminService;

    @Resource
    private StudentService studentService;

    @Resource
    private TeacherService teacherService;

    /*
     *   获取验证码图片返回给浏览器
     * @param session
     * @param response
     * @throws IOException
     * */

    @ApiOperation("获取验证码图片")
    @RequestMapping("/getVerifiCodeImage")
    public void getVerifiCodeImage(HttpSession session, HttpServletResponse response) throws IOException {
        //使用工具类，获取验证码
        BufferedImage verifiCodeImage = CreateVerifiCodeImage.getVerifiCodeImage();
        //获取一下验证码图片中的值
        String code = new String(CreateVerifiCodeImage.getVerifiCode());
        //将验证码的值保存到session域中，用于登陆时校验验证码
        session.setAttribute("code", code);
        //将验证码图片返回给浏览器
        ImageIO.write(verifiCodeImage, "JPG", response.getOutputStream());
    }

    /*
    * 登录功能  进行验证码的校验 以及用户名密码校验
    * 登陆成功时  生成token返回给浏览器
    * @param loginForm  生成的登录信息表单
    * @param session
    * @return
    * */

    @ApiOperation("登录功能 登陆成功将查询到的用户信息、用户类型 并封装id和userType成token 一起响应到浏览器")
    @PostMapping("/login")
    public Result<Object> login(@ApiParam("封装到实体类中请求体的json数据") @RequestBody LoginForm loginForm, HttpSession session) {
        //因为时post请求，所以要用@RequestBody来获取
        //先获取session域中的验证码值
        String code = (String) session.getAttribute("code");
        //判断是否失效
        if (code == null || "".equals(code)) {
            return Result.fail().message("验证码失效了，重新获取验证码");
        }
        //获取用户输入的验证码
        String userInputCode = loginForm.getVerifiCode();
        if (!userInputCode.equalsIgnoreCase(code)) {
            return Result.fail().message("验证码输入有误");
        }
        //销毁session域中的验证码的值
        session.removeAttribute("code");
        //获取用户类型 根据用户类型去相应的表中 做用户和密码的校验
        Integer userType = loginForm.getUserType();
        //获取用户输入的用户名和密码
        String username = loginForm.getUsername();
        String password = MD5.encrypt(loginForm.getPassword());
        Map<String, Object> map = new LinkedHashMap<>();
        if (userType == 1) {
            Admin admin = adminService.selectAdminByUsernameAnpwd(username, password);
            //判断输入的用户名和密码是否存在数据库中
            if (admin != null) {
                //登录成功后 需要根据用户Id和用户类型生成token 并返回给浏览器
                String token = JwtHelper.createToken(admin.getId().longValue(), userType);
                map.put("token", token);
                //需要将用户类型也返回给浏览器
                //map.put("userType", userType);
                return Result.ok(map);
            }
            return Result.fail().message("用户名或密码有误");
        } else if (userType == 2) {
            Student student = studentService.selectStudentByUsernameAnpwd(username, password);
            //判断输入的用户名和密码是否存在数据库中
            if (student != null) {
                //登录成功后 需要根据用户Id和用户类型生成token 并返回给浏览器
                String token = JwtHelper.createToken(student.getId().longValue(), userType);
                map.put("token", token);
                //需要将用户类型也返回给浏览器
                //map.put("userType", userType);
                return Result.ok(map);
            }
            return Result.fail().message("用户名或密码有误");
        } else {
            Teacher teacher = teacherService.selectTeacherByUsernameAnpwd(username, password);
            //判断输入的用户名和密码是否存在数据库中
            if (teacher != null) {
                //登录成功后 需要根据用户Id和用户类型生成token 并返回给浏览器
                String token = JwtHelper.createToken(teacher.getId().longValue(), userType);
                map.put("token", token);
                //需要将用户类型也返回给浏览器
                //map.put("userType", userType);
                return Result.ok(map);
            }
            return Result.fail().message("用户名火密码有误");
        }
    }

    /**
     * 解析 浏览器发送来的请求头中的token
     * @param token 浏览器发送来的token
     * @return 封装数据到Result类 响应给浏览器
     */
    @ApiOperation("将请求头中的token解析成id和用户类型 并根据id和类型查询用户信息 将信息和用户类型数据一起返回")
    @GetMapping("/getInfo")
    public Result<Object> getInfo(@ApiParam("请求头中的token数据") @RequestHeader("token") String token){
        //判断token是否有效
        if(JwtHelper.isExpiration(token)){
            return Result.build(null, ResultCodeEnum.TOKEN_ERROR);
        }
        //解析token 获取用户id和用户类型 将用户类型返回给浏览器
        Long userId = JwtHelper.getUserId(token);
        Integer userType = JwtHelper.getUserType(token);
        Map<String,Object> map = new LinkedHashMap<>();
        map.put("userType",userType);
        if (userType == 1){
            Admin admin = adminService.selectAdminById(userId);
            map.put("user",admin);
        } else if (userType == 2) {
            Student student = studentService.selectStudentById(userId);
            map.put("user",student);
        }else {
            Teacher teacher = teacherService.selectTeacherById(userId);
            map.put("user",teacher);
        }
        return Result.ok(map);
    }

    @ApiOperation("上传头像")
    @PostMapping("/headerImgUpload")
    public Result<Object> headerImgUpload(@ApiParam("封装请求体中的图片二进制数据") @RequestPart("multipartFile")MultipartFile multipartFile) throws IOException {
        //先获取上传文件的名称
        String originalFilename = multipartFile.getOriginalFilename();
        assert originalFilename != null;
        //获取文件格式 即后缀 如 .jpg .png .jepg
        String suffix = originalFilename.substring(originalFilename.lastIndexOf("."));
        //为了避免文件保存服务端时 文件名相同的冲突 导致文件覆盖 所以使用UUID随机生成数
        String fileName = UUID.randomUUID().toString().toLowerCase().replace("-", "").concat(suffix);
        //保存路径
        String savePath = "D:/IntelliJ IDEA 2022.3.2/porjects/smart_campus-master/smart_campus-master/module_campus/src/main/resources/static/upload/".concat(fileName);
        //进行文件保存到服务端
        multipartFile.transferTo(new File(savePath));
        return Result.ok("upload/".concat(fileName));
    }

}


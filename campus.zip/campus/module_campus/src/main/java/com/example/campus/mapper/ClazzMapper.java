package com.example.campus.mapper;

import com.example.campus.pojo.Clazz;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 范林峰
* @description 针对表【tb_clazz】的数据库操作Mapper
* @createDate 2024-09-10 19:03:41
* @Entity com.example.campus.pojo.Clazz
*/
public interface ClazzMapper extends BaseMapper<Clazz> {

}





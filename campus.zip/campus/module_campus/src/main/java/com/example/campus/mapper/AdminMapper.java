package com.example.campus.mapper;

import com.example.campus.pojo.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 范林峰
* @description 针对表【tb_admin】的数据库操作Mapper
* @createDate 2024-09-10 19:02:42
* @Entity com.example.campus.pojo.Admin
*/
public interface AdminMapper extends BaseMapper<Admin> {

}





package com.example.campus.mapper;

import com.example.campus.pojo.Student;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 范林峰
* @description 针对表【tb_student】的数据库操作Mapper
* @createDate 2024-09-10 19:03:48
* @Entity com.example.campus.pojo.Student
*/
public interface StudentMapper extends BaseMapper<Student> {

}





package com.example.campus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModuleCampusApplication {

    public static void main(String[] args) {
        SpringApplication.run(ModuleCampusApplication.class, args);
    }

}

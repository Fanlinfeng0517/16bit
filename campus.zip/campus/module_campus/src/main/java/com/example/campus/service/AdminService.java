package com.example.campus.service;

import com.example.campus.pojo.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 范林峰
* @description 针对表【tb_admin】的数据库操作Service
* @createDate 2024-09-10 19:02:42
*/
public interface AdminService extends IService<Admin> {

    Admin selectAdminByUsernameAnpwd(String username, String password);

    Admin selectAdminById(long id);
}

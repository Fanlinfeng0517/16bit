-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: smart_campus
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_admin`
--

DROP TABLE IF EXISTS `tb_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gender` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `telephone` varchar(12) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `portrait_path` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_admin`
--

LOCK TABLES `tb_admin` WRITE;
/*!40000 ALTER TABLE `tb_admin` DISABLE KEYS */;
INSERT INTO `tb_admin` VALUES (101,'admin','女','21232f297a57a5a743894a0e4a801fc3','111111@qq.com','13866666666','昌平','upload/default.jpg'),(102,'admin1','男','21232f297a57a5a743894a0e4a801fc3','333333@qq.com','13866666666','北京','upload/default.jpg'),(103,'admin2','男','21232f297a57a5a743894a0e4a801fc3','333333@qq.com','13866666666','北京','upload/default.jpg'),(104,'admin3','男','21232f297a57a5a743894a0e4a801fc3','333333@qq.com','13866666666','宏福苑','upload/default.jpg');
/*!40000 ALTER TABLE `tb_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_clazz`
--

DROP TABLE IF EXISTS `tb_clazz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_clazz` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `number` int DEFAULT NULL,
  `introducation` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `headmaster` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `telephone` varchar(12) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `grade_name` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_clazz`
--

LOCK TABLES `tb_clazz` WRITE;
/*!40000 ALTER TABLE `tb_clazz` DISABLE KEYS */;
INSERT INTO `tb_clazz` VALUES (1,'一年一班',30,'大圣的一年一班好','大圣','dasheng@163.com','13866666666','一年级'),(2,'一年二班',28,'小张的一年二班好','小张','xiaozhang@163.com','13866666666','一年级'),(3,'二年一班',35,'小韩的二年一班好','小韩','xiaohan@163.com','13866666666','二年级'),(4,'二年二班',30,'小强的二年二班好','小强','xiaoqiang@163.com','13866666666','二年级'),(5,'三年一班',30,'小花的三年一班好','小花','xiaohua@163.com','13866666666','三年级'),(6,'三年二班',30,'小赵的三年二班好','小赵','xiaozhao@163.com','13866666666','三年级'),(7,'四年一班',30,'小赵的三年二班好','小飞','xiaofei@163.com','13866666666','四年级'),(10,'五年一般',20,'tianfdsjfnsaifisdjfsd f ','小楼','154@qq.com','13478786549','五年级'),(11,'六年一般',20,'tianfdsjfnsaifisdjfsd f ','小嘚','154@qq.com','13478786549','六年级');
/*!40000 ALTER TABLE `tb_clazz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_grade`
--

DROP TABLE IF EXISTS `tb_grade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_grade` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `manager` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `telephone` varchar(12) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `introducation` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`,`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_grade`
--

LOCK TABLES `tb_grade` WRITE;
/*!40000 ALTER TABLE `tb_grade` DISABLE KEYS */;
INSERT INTO `tb_grade` VALUES (1,'一年级','大圣','dasheng@163.com','13866666666','大学一年级'),(2,'二年级','小魏','xiaowei@163.com','13866666666','大学二年级'),(3,'三年级','小李','xiaoli@163.com','13666666666','三年级,这个班级的孩子们很有才艺'),(4,'四年级','小丽','li@123.com','13666666666','大学四年纪 这个年级的同学多才多活力');
/*!40000 ALTER TABLE `tb_grade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_student`
--

DROP TABLE IF EXISTS `tb_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_student` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sno` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `name` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gender` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `telephone` varchar(12) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `introducation` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `portrait_path` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `clazz_name` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_student`
--

LOCK TABLES `tb_student` WRITE;
/*!40000 ALTER TABLE `tb_student` DISABLE KEYS */;
INSERT INTO `tb_student` VALUES (1,'1001','张小明','男','e10adc3949ba59abbe56e057f20f883e','yinyufei@163.com','13866666666','北京天通苑','这个学生学习好','upload/default.jpg','一年一班'),(2,'1002','郭建超','男','e10adc3949ba59abbe56e057f20f883e','guojianchao@163.com','13866666666','北京昌平','这个学生会功夫','upload/default.jpg','一年一班'),(3,'1003','史汶鑫','男','e10adc3949ba59abbe56e057f20f883e','shiwenxin@163.com','13866666666','北京昌平','这个学生酒量好','upload/default.jpg','二年一班'),(4,'1004','高建军','男','e10adc3949ba59abbe56e057f20f883e','gaojianjun@163.com','13866666666','北京昌平','这个学生会做饭','upload/default.jpg','二年一班'),(5,'1005','邹伟斌','男','e10adc3949ba59abbe56e057f20f883e','zouweibin@163.com','13866666666','北京昌平','这个学生能吃辣','upload/default.jpg','三年一班'),(6,'1006','刘路','男','e10adc3949ba59abbe56e057f20f883e','liulu@163.com','13866666666','北京昌平','这个学生是学霸','upload/default.jpg','三年二班'),(7,'1007','庞家仨','女','e10adc3949ba59abbe56e057f20f883e','pangjiasan@163.com','13866666666','北京昌平','这个学生海拔高','upload/default.jpg','三年二班'),(8,'1008','谭帅333','男','e10adc3949ba59abbe56e057f20f883e','tanshuai@163.com','13866666666','北京昌平','这个学生想考研','upload/default.jpg','四年一班'),(9,'1008','root','男','63a9f0ea7bb98050796b649e85481845','xiaohei@163.com','13868966666','北京昌平','这个学生想考研','upload/default.jpg','四年一班'),(10,'1009','小黑','男','e10adc3949ba59abbe56e057f20f883e','xiaoheizi@163.com','13866666666','北京昌平','这个学生想考研','upload/default.jpg','四年一班'),(11,'1001','王大明','男','123456','1684@qq.com','15837765451','河北保定','个人happy very good','upload/b18de25244414979807a43156f5007a4.jpg','五年一般');
/*!40000 ALTER TABLE `tb_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_teacher`
--

DROP TABLE IF EXISTS `tb_teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_teacher` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tno` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `name` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gender` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `telephone` varchar(12) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `portrait_path` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `clazz_name` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_teacher`
--

LOCK TABLES `tb_teacher` WRITE;
/*!40000 ALTER TABLE `tb_teacher` DISABLE KEYS */;
INSERT INTO `tb_teacher` VALUES (1,'101','大圣','女','e10adc3949ba59abbe56e057f20f883e','dasheng@163.com','13866666666','北京昌平','upload/default.jpg','一年一班'),(2,'102','小张','男','e10adc3949ba59abbe56e057f20f883e','xiaozhang@163.com','13866666666','北京海淀','upload/default.jpg','一年二班'),(3,'103','小韩','男','e10adc3949ba59abbe56e057f20f883e','xiaohan@163.com','13866666666','北京朝阳','upload/default.jpg','二年一班'),(4,'104','小强','男','e10adc3949ba59abbe56e057f20f883e','xiaoqiang@163.com','13866666666','北京通州','upload/default.jpg','二年二班'),(5,'105','小花','男','e10adc3949ba59abbe56e057f20f883e','xiaohua@163.com','13866666666','北京顺义','upload/default.jpg','三年一班'),(6,'106','小赵','男','e10adc3949ba59abbe56e057f20f883e','xiaozhao@163.com','13866666666','北京东城','upload/default.jpg','三年二班'),(7,'107','小飞','男','e10adc3949ba59abbe56e057f20f883e','xiaofei@163.com','13866666666','北京西城','upload/default.jpg','四年一班'),(8,'108','秀秀2','男','e10adc3949ba59abbe56e057f20f883e','123456@123.com','13855555555','海淀','upload/2977694e8da847e2a3e6f0af9416fbba.png','一年二班');
/*!40000 ALTER TABLE `tb_teacher` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-16 15:57:11
